#!/bin/bash

# Variables
USB_DEVICE="/dev/sda1"
MOUNT_POINT="/mnt/usb"
DATABASE_FILE="/opt/database/database.mv.db"
BACKUP_DIR="$MOUNT_POINT/backup"
TIMESTAMP=$(date +%Y-%m-%d)

# Ensure the mount point directory exists
if [ ! -d "$MOUNT_POINT" ]; then
    echo "Creating mount point directory at $MOUNT_POINT"
    sudo mkdir -p $MOUNT_POINT
fi

# Mount the USB drive
if mount | grep $MOUNT_POINT > /dev/null; then
    echo "USB drive already mounted."
else
    echo "Mounting USB drive..."
    sudo mount $USB_DEVICE $MOUNT_POINT
    if [ $? -ne 0 ]; then
        echo "Failed to mount USB drive."
        exit 1
    fi
fi

# Ensure backup directory exists
mkdir -p $BACKUP_DIR

# Copy the database file with a timestamp
echo "Copying database file to USB drive..."
cp $DATABASE_FILE $BACKUP_DIR/database_backup_$TIMESTAMP.mv.db
if [ $? -eq 0 ]; then
    echo "Backup completed successfully."
else
    echo "Backup failed."
    sudo umount $MOUNT_POINT
    exit 1
fi

# Unmount the USB drive
echo "Unmounting USB drive..."
sudo umount $MOUNT_POINT
if [ $? -eq 0 ]; then
    echo "USB drive safely unmounted."
else
    echo "Failed to unmount USB drive. Please try manually."
    exit 1
fa